<h3>ℌ𝔦 𝔱𝔥𝔢𝔯𝔢 👋, 𝔪𝔶 𝔫𝔞𝔪𝔢 𝔦𝔰 𝖁𝖎𝖈𝖙𝖔𝖗 𝕬𝖑𝖇𝖊𝖗𝖙𝖔 𝕲𝖎𝖑, </h3>
w҉e҉l҉c҉o҉m҉e҉ ҉t҉o҉ ҉m҉y҉ ҉r҉e҉p҉o҉s҉i҉t҉o҉r҉y҉!҉
  — I program 4 fun!

<img src="https://raw.githubusercontent.com/vhanla/vhanla/master/.gitassets/ascii.svg?raw=true" />

              🅵🅴🅴🅻 🅵🆁🅴🅴 🆃🅾 🅻🅴🅰🆅🅴 🆈🅾🆄🆁 🅵🅴🅴🅳🅱🅰🅲🅺, 🅰🅽🅳 🅳🅾🅽'🆃 🅵🅾🆁🅶🅴🆃 🆃🅾 🅻🅸🅺🅴

<h2 align="center">👋 Hi, Hola, Bonjour, Hallo, Ciao, こんにちは, 안녕하세요, 你好, Привет, Merhaba, مرحبا </h2>

<p align="center">
    <img src="https://komarev.com/ghpvc/?username=vhanla&color=blueviolet"/> 
</p>

### Welcome
This is my GitHub's open source repository page, I write **these** programs just to have fun, they are my hobbies, I try to make tools mainly for Windows using Object Pascal, C#, Assembly, Python, etc. and also web stuff.

Some of them are just proof of concepts, maybe they might remain as neverending WIP projects, or maybe some might get more attention and get continuous maintenance, as I said, they're hobby projects.

These are just simple open source projects, the advanced and complex projects are private, though. 😉
<br/>

<h2 align="center">📊 👩🏻‍💻</h2>

<p align="center">
  <img height="50%" width="auto" src ="https://readme-stats-teal-alpha.vercel.app/api?username=vhanla&show_icons=true&count_private=true&theme=material-palenight&hide_border=true&hide=issues,contribs&bg_color=00000000">
  <img height="50%" width="auto" src ="https://readme-stats-teal-alpha.vercel.app/api/top-langs/?username=vhanla&layout=compact&hide_border=true&theme=material-palenight&bg_color=00000000&langs_count=6&hide=jupyter%20notebook,tex,css,php&exclude_repo=Pacman-AI">
  <img src ="https://github-readme-streak-stats.herokuapp.com?user=vhanla&theme=material-palenight&hide_border=true&background=FFFFFF00">
</p>
<details>
  <summary>:zap: 🏆🎖️🏅</summary>
<p align="center">
    <img src="https://github-profile-trophy.vercel.app/?username=vhanla&theme=transparent"/>
</p>
</details>

<h4 align="center">👨🏻‍💻 Playing tools: </h4>

<p align="center">
  <a href="https://github.com/search?q=user%3Avhanla+language%3Aassembly"><img alt="Assembler" src="https://custom-icon-badges.demolab.com/badge/asm-x86-gray.svg?logo=asm&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Apascal"><img alt="Pascal" src="https://custom-icon-badges.demolab.com/badge/Pascal-ff0101.svg?logo=delphi&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Acpp"><img alt="C++" src="https://custom-icon-badges.demolab.com/badge/C++-0086d4.svg?logo=cpp&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Apython"><img alt="Python" src="https://custom-icon-badges.demolab.com/badge/Python-green.svg?logo=python&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Acsharp"><img alt="C#" src="https://custom-icon-badges.demolab.com/badge/C%23-68217A.svg?logo=cs2&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Ago"><img alt="Go" src="https://custom-icon-badges.demolab.com/badge/Go-blue.svg?logo=go&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Acss"><img alt="CSS" src="https://img.shields.io/badge/CSS-1572B6.svg?logo=css3&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Ahtml"><img alt="HTML" src="https://img.shields.io/badge/HTML-E34F26.svg?logo=html5&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Ajavascript"><img alt="JavaScript" src="https://img.shields.io/badge/JavaScript-F7DF1E.svg?logo=javascript&logoColor=black"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Amarkdown"><img alt="Markdown" src="https://img.shields.io/badge/Markdown-000000.svg?logo=markdown&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3Asql"><img alt="SQL" src="https://custom-icon-badges.demolab.com/badge/SQL-025E8C.svg?logo=database&logoColor=white"></a>
  <a href="https://github.com/search?q=user%3Avhanla+language%3AtypeScript"><img alt="TypeScript" src="https://img.shields.io/badge/TypeScript-007ACC.svg?logo=typescript&logoColor=white"></a>
</p>

Thanks for reading. Take care.
![anim](https://raw.githubusercontent.com/vhanla/vhanla/master/.gitassets/walkingmario.gif)

<!--
[![Readme Card](https://readme-stats-teal-alpha.vercel.app/api/pin/?username=vhanla&repo=winxcorners)](https://github.com/vhanla/winxcorners)
**vhanla/vhanla** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
```asm
                                  _________
                                 | _____  o|
                                 |[_-_]_   |
      ______________________     |[_______]|       global _main               |   org 100h    
     |.--------------------.|    |[_______]|       extern _printf             |
     ||                    ||    |[====o]  |                                  |   mov dx, msg
     ||    H͓̽e͓̽l͓̽l͓̽o͓̽ ͓̽w͓̽o͓̽r͓̽l͓̽d͓̽!͓̽    ||    |[_______]|       section .text              |   mov ah, 9
     ||                    ||    |        :|   _main:                         |   int 21h
     ||____________________||    |        :|       push message               |   
 .==.|""      ......        |.==.|        :|       call _printf               |   mov ah, 4Ch
 |::| '-.________________.-' |::||        :|       add esp, 4                 |   int 21h
 |''|  (__________________)-.|''||________:|       ret                        |
 `""`_......................_\""`______        message:                       |   msg db 'Hello, guys!', 0Dh, 0Ah, '$' 
    /::::::::::::::::::::'':::\`|'-.-.  `\         db 'Hello, world!', 10, 0  |
   /::==================.:.-::"\ \ \--\   \
   \`"""""""""""""""""""""""""`/  \ \__)   \
    `"""""""""""""""""""""""""`    '========'
```

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

